# setup.py
from distutils.core import setup

setup(name='lab10',
    version='1.0',
    author='Mikolaj Mazurek',
    author_email='mikolajmazurek@gmail.com',
    url='https://github.com/mikolaj965/DPP_Lab10/',
    packages=['lab10'],
)

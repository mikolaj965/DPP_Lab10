
def fahrToKelv(temp): 

    kelvin = 5./9. * (temp - 32.) + 273.15

    return kelvin

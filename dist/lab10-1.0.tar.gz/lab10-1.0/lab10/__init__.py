

def calculatedelta(a, b, c):
    delta = b*b - 4*a*c
    return delta
